#!/bin/bash

clear
/root/hello-world

printf "\n\n\n"
printf "\nThe source code can be found in hello-world.cbl\n\n"

printf "Run \"cobc -free -x -o hello-world hello-world.cbl\" to compile.\n\n----------------------------------\n"
